import React from 'react'

const OfflineClientsTable = () => {
    return (
        <div>OfflineClientsTable</div>
    )
}

export default OfflineClientsTable