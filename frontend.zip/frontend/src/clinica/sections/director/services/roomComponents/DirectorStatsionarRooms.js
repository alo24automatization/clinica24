import React from 'react'
import { TableRooms } from './TableRooms'

function DirectorStatsionarRooms(props) {
  return (
    <TableRooms {...props} />
  )
}

export default DirectorStatsionarRooms