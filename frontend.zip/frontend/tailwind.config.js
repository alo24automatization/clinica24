module.exports = {
    content: [
        "./src/**/*.{js,jsx,ts,tsx}",
    ],
    theme: {
        extend: {
            colors: {
                alotrade: "#00c2cb"
            }
        },
    },
    plugins: [],
}
